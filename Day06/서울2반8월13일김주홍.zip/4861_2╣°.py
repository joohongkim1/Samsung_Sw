t = int(input())

for tc in range(1, t+1):
    n, m = map(int, input().split())
    result = []

    garo = []
    for i in range(n):
        data = input()
        garo.append(data)

        for i in range(len(data)-m+1):
            if data[i:m+i] == data[i:m+i][::-1]:
                result.append(data[i:m+i])

    sero = []
    sub = ''
    for x in range(n):
        for y in garo:
            sub += y[x]
        sero.append(sub)
        sub =''

    for s in sero:
        for j in range(len(s)-m+1):
            if s[j:m+j] == s[j:m+j][::-1]:
                result.append(s[j:m+j])

    print("#%d %s"%(tc, result[0]))